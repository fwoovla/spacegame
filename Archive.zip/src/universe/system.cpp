#include "system.hpp"
#include "../game.h"

System::System( SystemMapData &_map_data ) : map_data(_map_data) {
}

void System::GenerateSystem(SelectionManager *sm) {

    printf("generating system %i with  %i planets\n", map_data.uid, map_data.bodies.size());

    selection_manager = sm;

    system_data.uid = map_data.uid;

    system_data.radius = map_data.radius;
    system_data.seed = GetRandomValue(100, 100000);

    system_data.star_position = map_data.star_position;    

    //system_data.body_data = map_data.body_data;    
    
    for(auto &body : map_data.bodies) {
        SpawnSystemBody(body.second);
    }

    for(auto &location : map_data.locations) {
        SpawnSystemLocation(location.second);
    }

    for(auto &site : map_data.sites) {
        SpawnSystemSite(site.second);
    }

    ResolveParents();

    for(int i = 0; i < 10; i++) {
        EntityData asteroid = GenerateEntityInstance(g_entity_template_data[ENTITY_ASTEROID], system_data.star_position );
        system_data.entity_data[asteroid.uid] = asteroid;

        SpawnObjectEntity(asteroid);
    }


/*     EntityData asteroid = GenerateEntityInstance(g_entity_template_data[ENTITY_ASTEROID], system_data.star_position );
    system_data.entity_data[asteroid.uid] = asteroid;

    SpawnObjectEntity(asteroid); */

    RegisterWithManagers();

}



void System::Update() {
    for(auto &site : system_data.site_list) {
        site->Update();
    }

    for(auto &location : system_data.location_list) {
        location->Update();
    }

    for(auto &body : system_data.body_list) {
        body->Update();
    }

    auto &creatures = system_data.creature_entity_list;

    for (auto &creature : creatures) {
        creature->Update();
    }
    std::erase_if(creatures, [](const std::unique_ptr<CreatureEntity> &entity){return entity->should_delete;});

    
    auto &objects = system_data.object_entity_list;

    for (auto &object : objects) {
        object->Update();
    }
    std::erase_if(objects, [](const std::unique_ptr<ObjectEntity> &entity){return entity->should_delete;});

    
}



void System::Draw() {

}


void System::DrawWorld() {

    DrawRectangle(0, 0, g_viewport.resolution.x, g_viewport.resolution.y, SPACEBLUE);
    
    for(auto &body : system_data.body_list) {
        body->Draw();
        //DrawCircleLinesV(body->body_data->position, body->body_data->detect_radius, WHITE);
    }
    for(auto &location : system_data.location_list) {
        location->Draw();
        //DrawCircleLinesV(location->location_data->position, location->location_data->detect_radius, WHITE);
    }

    for(auto &site : system_data.site_list) {
        site->Draw();
        //DrawCircleLinesV(site->site_data->position, site->site_data->detect_radius, WHITE);
    }
    
    for(auto &creature : system_data.creature_entity_list) {
        if(creature->entity_data->render_mode == RENDER_WORLD) {
            creature->Draw();
        }
            
    }
    for(auto &object : system_data.object_entity_list) {
        //printf("object Draw -sys  %i\n", object->entity_data->render_mode);
        if(object->entity_data->render_mode == RENDER_WORLD) {
            //printf("object Draw -sys\n");
            object->Draw(); 
        }
    }
}

void System::DrawOverlay() {

    for(auto &body : system_data.body_list) {
        body->DrawOverlay();
    }
    for(auto &location : system_data.location_list) {
        location->DrawOverlay();
    }
    for(auto &site : system_data.site_list) {
        site->DrawOverlay();
    }
    
    
    for(auto &creature : system_data.creature_entity_list) {
        if(creature->entity_data->render_mode != RENDER_WORLD) {
            creature->DrawOverlay();
        }
    }
    for(auto &object : system_data.object_entity_list) {
        //printf("object Draw overlay -sys  %i\n", object->entity_data->render_mode);
        if(object->entity_data->render_mode != RENDER_WORLD) {
            printf("object Draw overlay -sys\n");
            object->DrawOverlay();
        }
    }
}


void System::DrawDebug() {


}

void System::DrawUI() {

    for(auto &entity : system_data.creature_entity_list) {
        entity->DrawUI();
    }
    for(auto &site : system_data.site_list) {
        site->DrawUI();
    }
    
    for(auto &location : system_data.location_list) {
        location->DrawUI();
    }
    for(auto &body : system_data.body_list) {
        body->DrawUI();
    }
    for(auto &object : system_data.object_entity_list) {
        object->DrawUI();
    }
}


PlayerCharacter * System::SpawnNewPlayer(EntityTemplateData &tmpl, int uid, Vector2 position) {

    EntityData entity_data = GenerateEntityInstance(tmpl, position);
    entity_data.uid = uid;
    system_data.entity_data[entity_data.uid] = entity_data;

    std::unique_ptr<PlayerCharacter> player = std::make_unique<PlayerCharacter>(&system_data.entity_data[entity_data.uid]);
    PlayerCharacter * ptr = player.get();
    system_data.creature_entity_list.push_back(std::move(player));

    return ptr;
}


PlayerCharacter * System::SpawnPlayer(EntityData data, Vector2 position) {

    system_data.entity_data[data.uid] = data;

    std::unique_ptr<PlayerCharacter> player = std::make_unique<PlayerCharacter>(&system_data.entity_data[data.uid]);
    PlayerCharacter * ptr = player.get();
    system_data.creature_entity_list.push_back(std::move(player));

    return ptr;
}

 SystemBody * System::SpawnSystemBody(SystemBodyData &data) {

    std::unique_ptr<SystemBody> body = std::make_unique<SystemBody>(&data);
    SystemBody * ptr = body.get();

    system_data.body_list.push_back(std::move(body));
    //printf("spawning body  type: %i  |uid: %i   |parent uid: %i\n",ptr->body_data->body_type , ptr->body_data->uid, ptr->body_data->parent_uid);
    return ptr;

 }



SystemLocation * System::SpawnSystemLocation(SystemLocationData &data) {
    std::unique_ptr<SystemLocation> location = std::make_unique<SystemLocation>(&data);
    SystemLocation * ptr = location.get();

    system_data.location_list.push_back(std::move(location));
    //printf("spawning location   |uid: %i   |body uid: %i\n", ptr->location_data->uid, ptr->location_data->body_uid);
    return ptr;
}


SystemSite * System::SpawnSystemSite(SystemSiteData &data) {
    std::unique_ptr<SystemSite> site = std::make_unique<SystemSite>(&data);
    SystemSite * ptr = site.get();

    system_data.site_list.push_back(std::move(site));
    //printf("spawning site   |uid: %i   |body uid: %i\n", ptr->site_data->uid, ptr->site_data->body_uid);
    return ptr;
}




ObjectEntity * System::SpawnObjectEntity(EntityData &data) {
    //printf("spawning object entity %i\n", data.id);

    system_data.entity_data[data.uid] = data;

    if(system_data.entity_data[data.uid].id == ENTITY_ASTEROID) {
        std::unique_ptr<AsteroidEntity> object = std::make_unique<AsteroidEntity>(&system_data.entity_data[data.uid]);

        AsteroidEntity * ptr = object.get();
        system_data.object_entity_list.push_back(std::move(object));
        printf("spawning asteroid entity\n");
        return ptr;
        
    }

    return nullptr;
}



 void System::ResolveParents() {

    for (auto &body : system_data.body_list) {
        body->parent_data = {};

        int p_uid = body->body_data->parent_uid;

        if (p_uid == -1)
            continue;

        auto it = map_data.bodies.find(p_uid);

        if (it != map_data.bodies.end())
            body->parent_data = &it->second;
    }
}



void System::SetCameraState(CAMERA_STATE new_state) {
    printf("system: camera change %i\n", new_state);
    g_game_data.camera_state = new_state;
    g_game_data.do_camera_transition = true;

}

void System::RegisterWithManagers(){
    for(auto &site : system_data.site_list) {
        site->RegisterWithManagers(selection_manager);
    }
    for(auto &location : system_data.location_list) {
        location->RegisterWithManagers(selection_manager);
    }
    for(auto &body : system_data.body_list) {
        body->RegisterWithManagers(selection_manager);
    }

    for(auto &object : system_data.object_entity_list) {
        object->RegisterWithManagers(selection_manager);
    }

}