#pragma once
#include <raylib.h>
#include "../../input/selectionmanager.hpp"
#include <vector>
#include <string>


struct SiteLocalData {
    int uid = -1;
    std::string name = "no site name";
};


struct LocationLocalData {
    int uid = -1;
    std::string name = "no location name";
    int site_amount = 0;
    int size = 0;

    std::vector<int> site_uids;
};


struct BodyLocalData {
    int uid = -1;
    std::string name = "no body name";
};




enum STAR_TYPE {
    REDDWARF,
    WHITEDWARF,
    BLUESTAR,
    GIANT,
    YELLOWSTAR,
    NEUTRONSTAR,
    BLACKHOLE,
    STAR_TYPE_COUNT
};

enum BODY_COMPOSITION {
    TERRESTRIAL,
    SUPEREARTH,
    NEPTUNIAN,
    GASGIANT,
    BODY_COMPOSITION_COUNT
};


enum BODY_ENVIRONMENT {
    TEMPERATE,
    DESERT,
    OCEAN,
    FROZEN,
    VOLCANIC,
    TOXIC,
    BODY_ENVIRONMENT_COUNT
};






enum BODY_TYPE {
    BODY_STAR,
    BODY_PLANET,
    BODY_MOON,
};


class SystemBody;
struct SystemBodyData {
    SystemBody *body_instance;
    BodyLocalData local_data;  //economy population etc...

    int uid = -1;
    int system_uid;
    std::string name = "no body name";

    Vector2 position;

    float radius = 0.0f;
    float detect_radius = 0.0f;
    float orbit_radius = 0.0f;
    float orbit_angle = 0.0f;


    BODY_TYPE body_type;
    BODY_COMPOSITION body_composition = TERRESTRIAL;
    BODY_ENVIRONMENT body_environment = TEMPERATE;

    bool landable = false;
    
    int orbital_layer_count = 0;
    float orbital_layer_delta;
    int orbital_body_count = 0;
    std::vector<int> orbital_body_uids;
    std::vector<int> location_uids;
    
    bool obstructable = false;
    Color modulate;
    
    int parent_orbital = 0;  //where it is in relation to it's parent orbitals
    int parent_uid = -1;

    
};



struct LocationPlan {
    int size_x = 10;
    int size_y = 10;
    int grid_size = 32;

    Vector2 px_offset;
    
    std::unordered_map<int, Vector2> site_locations;
    
};


class SystemLocation;

struct SystemLocationData {
    SystemLocation *location_instance;
    LocationPlan location_plan;
    LocationLocalData local_data;  //economy population etc...

    int uid = -1;
    int body_uid = -1;
    int system_uid = -1;
    std::string name = "no location name";
    Vector2 position;

    float radius = 0.0f;
    float detect_radius = 0.0f;

    std::vector<int> site_uids;

};

class SystemSite;
struct SystemSiteData {
    SystemSite *site_instance;
    SiteLocalData local_data;
    int uid = -1;
    int location_uid = -1;
    int body_uid = -1;
    int system_uid = -1;
    std::string name = "no site name";
    Vector2 position;

    float radius = 0.0f;
    float detect_radius = 0.0f;
};


//==========================================================================




class SystemObject  {
    public:
        virtual ~SystemObject() = default;
        virtual void Update() = 0;   
        virtual void Draw() = 0; 
        virtual void DrawOverlay() = 0;
        virtual void DrawUI() = 0;
        virtual float GetRenderScale() = 0;
        virtual void RegisterWithManagers(SelectionManager *sm) = 0;

        bool is_on_screen = false;
        bool y_sort = false;

        MouseTriggerArea info_area;
        Label info_label;

        SelectionManager *selection_manager;

        Signal player_approaching;
        Signal player_departing;

        
};



class SystemBody : public SystemObject {
    public:
        SystemBody(SystemBodyData *_data);
        ~SystemBody();
        void Update() override;
        void Draw() override;        
        void DrawOverlay() override;
        void DrawUI()override;

        float GetRenderScale() override;
        void RegisterWithManagers(SelectionManager *sm) override;

        SystemBodyData *body_data = nullptr;

        SystemBodyData *parent_data = nullptr;
}; 


class SystemLocation : public SystemObject {
    public:
        SystemLocation(SystemLocationData *_data);
        ~SystemLocation();
        void Update() override;
        void Draw() override;        
        void DrawOverlay() override;
        void DrawUI()override;

        float GetRenderScale() override;
        void RegisterWithManagers(SelectionManager *sm) override;

        SystemLocationData *location_data = nullptr;

        SystemBody *parent;
}; 

class SystemSite : public SystemObject {
    public:
        SystemSite(SystemSiteData *_data);
        ~SystemSite();
        void Update() override;
        void Draw() override;        
        void DrawOverlay() override;
        void DrawUI()override;

        float GetRenderScale() override;
        void RegisterWithManagers(SelectionManager *sm) override;

        SystemSiteData *site_data = nullptr;

        SystemBody *parent;
}; 




LocationLocalData GenerateLocationLocalData(int size);
LocationPlan GenerateNewPlan(LocationLocalData local_data);