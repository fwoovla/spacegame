#include "selectionmanager.hpp"
#include "../game.h"
#include <raymath.h>



SelectionManager::SelectionManager() {

}

void SelectionManager::Update() {

    if(g_input.in_use) {
        return;
    }

    Vector2 mouse_pos = g_input.world_mouse_position;

    AreaResult result = GetSelection(mouse_pos);

    MouseTriggerArea* new_hover = result.area;

    if(new_hover != current_hover)
    {
        if(current_hover)
        {
            current_hover->mouse_hovering = false;
            current_hover->mouse_exited.EmitSignal();
        }

        current_hover = new_hover;

        if(current_hover) {

            current_hover->mouse_hovering = true;
            current_hover->mouse_entered.EmitSignal();
        }
    }
    if(current_hover) {

        if(g_input.mouse_left) {
            if(selection != nullptr) {
                deselected.EmitSignal();
                selection->selected = false;
            }
            selection = current_hover;
            current_hover->selected = true;
            printf("hovered area clicked:---- body:%i  location:%i  site:%i\n", current_hover->body_payload, current_hover->location_payload, current_hover->landing_site_payload);
            selected.EmitSignal();
        }
    }
    else if(!current_hover and g_input.mouse_left) {
        if(selection != nullptr) {
            selection->selected = false;
        }
        deselected.EmitSignal();
        selection = nullptr;
    }
}



AreaResult SelectionManager::GetSelection(Vector2 mouse_pos) {
    AreaResult result;

    for(MouseTriggerArea* area : areas) {

        if(area == nullptr)
            continue;

        if(area->shape == MouseTriggerArea::CIRCLE)
        {
            float dist = Vector2Distance(mouse_pos, area->position);

            if(dist < area->radius)
            {
                // higher priority wins
                if(area->priority > result.priority ||
                   (area->priority == result.priority && dist < result.distance))
                {
                    result.area = area;
                    result.distance = dist;
                    result.priority = area->priority;
                }
            }
        }
    }

    return result;
}




void SelectionManager::Register(MouseTriggerArea *area) {
    areas.push_back(area);
    //printf("registering area:---- body:%i  location:%i  site:%i\n", area->body_payload, area->location_payload, area->landing_site_payload);
}

void SelectionManager::Unregister(MouseTriggerArea *area) {
    if(area == current_hover) {
        current_hover = nullptr;
    }
    std::erase(areas, area);
}


void SelectionManager::UnregisterAll() {
    current_hover = nullptr;
    selection = nullptr;
    for(auto & area : areas) {
        area->selected = false;
        area->mouse_hovering = false;
    }
    areas.clear();
    selected.DisconnectAll();
    deselected.DisconnectAll();
}



/* 
BaseEntity::~BaseEntity() {
            printf("BaseEntity destructor: %p  SM: %p  area: %p\n", this, selection_manager, &info_area);
            if (selection_manager){
                selection_manager->Unregister(&info_area);
            }
        } */