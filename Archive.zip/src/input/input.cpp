#include "../game.h"
#include "input.hpp"


void GetInputFromPlayer() {

    Vector2 m_pos = GetMousePosition();

    m_pos.x = m_pos.x * g_viewport.inv_scale;
    m_pos.y = m_pos.y * g_viewport.inv_scale;

    
    g_input.screen_mouse_position =  m_pos;


    g_input.world_mouse_position = GetScreenToWorld2D(m_pos, g_camera);

    g_input.mouse_left = IsMouseButtonPressed(MOUSE_BUTTON_LEFT);

    if(g_input.mouse_left) {
        g_input.mouse_left_clicked_screen_position = g_input.screen_mouse_position;
        g_input.mouse_left_clicked_world_position = g_input.world_mouse_position;
    }
    
    g_input.mouse_left_down = IsMouseButtonDown(MOUSE_BUTTON_LEFT);
    if(!g_input.mouse_left_down) {
        g_input.selecting = false;
        g_input.selected_rect = {0,0,0,0};
    }


    g_input.mouse_right = IsMouseButtonPressed(MOUSE_BUTTON_RIGHT);

    if(g_input.mouse_right) {
        g_input.mouse_right_clicked_screen_position = g_input.screen_mouse_position;
        g_input.mouse_right_clicked_world_position = g_input.world_mouse_position;
    }
    g_input.mouse_right_down = IsMouseButtonDown(MOUSE_BUTTON_RIGHT);
    
    g_input.mouse_middle = IsMouseButtonPressed(MOUSE_BUTTON_MIDDLE);
    g_input.mouse_middle_down = IsMouseButtonDown(MOUSE_BUTTON_MIDDLE);

    g_input.mouse_wheel = GetMouseWheelMove();
    
    
    memset(g_input.keys_pressed, KEY_NULL, KEY_BUFFER_SIZE);

    int key = GetKeyPressed();
    while(key != 0) {
        //TraceLog(LOG_INFO, "next key %i", key);
        for(int i = 0; i < KEY_BUFFER_SIZE; i++) {
            if(g_input.keys_pressed[i] == 0) {
                g_input.keys_pressed[i] = (KeyboardKey)key;
                //TraceLog(LOG_INFO, "indexing key %i", i);
                break;
            }
        }
        key = GetKeyPressed();
        
    } 

    g_input.key_up = IsKeyDown(KEY_W);
    g_input.key_down = IsKeyDown(KEY_S);
    g_input.key_left = IsKeyDown(KEY_A);
    g_input.key_right = IsKeyDown(KEY_D);

    g_input.key_throttle_up = IsKeyDown(KEY_Q);

    g_input.key_throttle_down = IsKeyDown(KEY_Z);

    g_input.key_switch_weapon = IsKeyDown(KEY_Q);

    g_input.key_reload = IsKeyDown(KEY_R);

    if(g_input.selecting) {
        
        float _x = 0.0f;
        float _y = 0.0f;
        float _width = 0.0f;
        float _height = 0.0f;

        if(g_input.world_mouse_position.x > g_input.mouse_left_clicked_world_position.x) {
            _x = g_input.mouse_left_clicked_world_position.x;
            _width = g_input.world_mouse_position.x - g_input.mouse_left_clicked_world_position.x;
        }
          else {
            _x = g_input.world_mouse_position.x;
            _width = g_input.mouse_left_clicked_world_position.x - g_input.world_mouse_position.x;
        }

        if(g_input.world_mouse_position.y > g_input.mouse_left_clicked_world_position.y) {
            _y = g_input.mouse_left_clicked_world_position.y;
            _height = g_input.world_mouse_position.y - g_input.mouse_left_clicked_world_position.y;
        }
        else {
            _y = g_input.world_mouse_position.y;
            _height = g_input.mouse_left_clicked_world_position.y - g_input.world_mouse_position.y;
        }

        g_input.selected_rect = {
            .x = _x,
            .y = _y,
            .width = _width,
            .height = _height
        };
    }

    if(g_input.mouse_left and !g_input.selecting) {
        g_input.selecting = true;
        //TraceLog(LOG_INFO, "SELECTING ");
    }
    if(g_input.selecting) {
        //TraceLog(LOG_INFO, "SELECTING ");
    }


}