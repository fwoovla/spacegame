#pragma once

#include <raylib.h>
#include <string>
#include "../uilayers/uilayers.hpp"
#include "../universe/universe.hpp"


enum SCENE_ID {
    SCENE_NONE,
    SCENE_SPLASH,
    SCENE_TITLE,
    SCENE_GAME,
    SCENE_TEST,
};

class BaseScene {
    public:
    virtual ~BaseScene(){};
    virtual SCENE_ID Update() = 0;
    virtual void DrawScene() = 0;
    virtual void DrawUI() = 0;
    
    SCENE_ID scene_id = SCENE_SPLASH;
    SCENE_ID return_scene = SCENE_NONE;

    //MapData map_data;        
};


class SplashScene : public  BaseScene{
    public:
        SplashScene();
        ~SplashScene() override;
        SCENE_ID Update() override;
        void DrawScene() override;
        void DrawUI() override;
        void OnTimerTimeout();

        //Timer timer;
    };


class TitleScene : public  BaseScene{
    public:
        TitleScene();
        ~TitleScene() override;
        SCENE_ID Update() override;
        void DrawScene() override;
        void DrawUI() override;

        void OnStartButtonPressed();
        void OnExitButtonPressed();
        void OnSettingsButtonPressed();
        
        std::unique_ptr<TitleUiLayer> ui;
};






class GameScene : public  BaseScene{
    public:
        GameScene();
        ~GameScene() override;
        SCENE_ID Update() override;
        void DrawScene() override;
        void DrawUI() override;

        void OnWorldTick();
        void OnEnterShip();
        void OnExitShip();
        
        //std::unique_ptr<GameUiLayer> ui;
        GameUiLayer ui;

        Timer world_ticker;

        UniverseManager universe_manager;

        bool location_active = false;
        bool should_destroy_location = false;

};



class LocationTestScene : public  BaseScene{
    public:

        LocationTestScene();
        ~LocationTestScene() override;
        SCENE_ID Update() override;
        void DrawScene() override;
        void DrawUI() override;

        void OnSizeXChanged();
        void OnSizeYChanged();
        void OnGridSizeChanged();

        void OnRegenerateLocation();

        LocationTestSceneUiLayer ui;


        LocationLocalData local_data;
        LocationPlan plan;

        //Timer timer;
    };
