#pragma once

#include "resources/resources.h"
#include "data/data.hpp"
#include "render/render.hpp"
#include "viewport/viewport.hpp"
#include "scenes/scenemanager.hpp"
#include "input/input.hpp"

#define RES_X 1280.0f
#define RES_Y 720.0f

struct DebugData {
    int dummy;
    float update_time = 0.0f;
    float render_time = 0.0f;

    int draw_count = 0;
    
};

struct SharedTransitionData {
    Vector2 return_position;
    int site_id;
    int location_id;
    int body_id;
    int system_id;
};

struct SharedSelectionData {
    Vector2 return_position;
    int site_id;
    int location_id;
    int body_id;
    int system_id;
};

struct GameData {
    std::string player_name = "no name";
    int tick_rate  = 10;
    bool running = false;
    bool show_debug;
    SHOP_TYPE shop_type;
    DebugData debug_data;

    CAMERA_STATE camera_state = CAMERA_SYSTEM;
    bool do_camera_transition = false;

    SharedTransitionData transition;
    SharedSelectionData selection;

    
};

extern GameData g_game_data;

class Game {
    public:
        Game();
        ~Game();
        void StartGame();
        void CleanUpGame();

        SceneManager scene_manager;
        Render render;
};

